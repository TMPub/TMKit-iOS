//
//  TMHTTPDNSGoogle.h
//  TMetworking
//
//  Created by TMKit on 2022/2/18.
//  Copyright © 2022 TMKit. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TMHTTPDNSBase.h"

@interface TMHTTPDNSGoogle : TMHTTPDNSBase <HTTPDNSBaseProtocol>

@end
