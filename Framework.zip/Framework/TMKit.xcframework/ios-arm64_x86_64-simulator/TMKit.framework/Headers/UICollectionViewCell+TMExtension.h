//
//  UICollectionViewCell+TMExtension.h
//  TMExtensions
//
//  Created by TMKit on 2021/7/30.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UICollectionViewCell (TMExtension)

+ (NSString *)tm_reuseIdentifier;

+ (NSString *)tm_reuseIdentifier_1;

@end

NS_ASSUME_NONNULL_END
