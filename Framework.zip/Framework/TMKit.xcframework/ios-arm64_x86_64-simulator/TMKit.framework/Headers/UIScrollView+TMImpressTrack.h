//
//  UIScrollView+TMImpressTrack.h
//  TMEVL
//
//  Created by TMKit on 2022/6/14.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIScrollView (TMImpressTrack)

+ (void)tmSwizzle;

@end

NS_ASSUME_NONNULL_END
