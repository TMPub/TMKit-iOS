//
//  TMFPSLabel.h
//  TMUI
//
//  Created by TMKit on 2022/7/27.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TMFPSLabel : UILabel

@end

NS_ASSUME_NONNULL_END
