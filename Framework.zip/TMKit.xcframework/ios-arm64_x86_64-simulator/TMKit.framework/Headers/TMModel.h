//
//  TMModel.h
//  TMKit
//
//  Created by TMKit on 2022/7/18.
//

#import "NSObject+TMModel.h"
#import "TMModelBase.h"
