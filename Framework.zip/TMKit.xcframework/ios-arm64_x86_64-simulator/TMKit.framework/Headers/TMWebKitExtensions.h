//
//  TMWebKitExtensions.h
//  TMExtensions
//
//  Created by TMKit on 2022/8/2.
//

#ifndef TMWebKitExtensions_h
#define TMWebKitExtensions_h

#import "WKWebView+TMExtension.h"

#endif /* TMWebKitExtensions_h */
